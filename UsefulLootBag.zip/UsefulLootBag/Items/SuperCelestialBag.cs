﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace UsefulLootBag.Items
{
	public class SuperCelestialBag : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Super Celestial Bag");
			Tooltip.SetDefault("<right> to get lunar fragments!");
		}

		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 20;
			item.rare = 10;
			item.maxStack = 999;
		}

		public override bool CanRightClick()
		{
			return true;
		}

		public override void RightClick(Player player)
		{
			player.QuickSpawnItem(ItemID.FragmentNebula, 50);
			player.QuickSpawnItem(ItemID.FragmentSolar, 50);
			player.QuickSpawnItem(ItemID.FragmentStardust, 50);
			player.QuickSpawnItem(ItemID.FragmentVortex, 50);
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.FallenStar, 800);
			recipe.AddIngredient(ItemID.LunarBar, 8);
			recipe.AddIngredient(ItemID.GoldBar, 20);
			recipe.AddTile(TileID.LunarCraftingStation);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}