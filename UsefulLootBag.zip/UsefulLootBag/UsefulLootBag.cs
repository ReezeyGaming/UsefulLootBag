using Terraria.ModLoader;

namespace UsefulLootBag
{
	public class UsefulLootBag : Mod
	{
	}
}